# Homework 1 - Git and Github

My submission for CPSC 131 Homework 1

# My Information

* Name: Steven Ly
* CWID: 886758556
* Email: stevenly3030@csu.fullerton.edu
